package com.learnersacademy.admin;

public record DbRetrieve() {

}
